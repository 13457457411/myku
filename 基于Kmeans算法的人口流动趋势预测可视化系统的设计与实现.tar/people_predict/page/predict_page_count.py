from rest_framework.views import APIView
from django.shortcuts import render



class PredictCount(APIView):

    def get(self,request):

        return render(request, "predict_count.html")