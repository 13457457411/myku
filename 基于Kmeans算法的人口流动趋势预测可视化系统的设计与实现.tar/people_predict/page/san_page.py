from rest_framework.views import APIView
from django.shortcuts import render



class San(APIView):

    def get(self,request):
        return render(request, "san.html")