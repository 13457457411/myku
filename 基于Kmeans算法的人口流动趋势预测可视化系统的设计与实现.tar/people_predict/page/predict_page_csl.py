from rest_framework.views import APIView
from django.shortcuts import render



class PredictCSL(APIView):

    def get(self,request):

        return render(request, "predict_csl.html")