"""provinceData URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))

    可以坐预测的历史数 城市的根本找不到= = 这是去统计局爬取的中国人口的

    老师问就照实说就好了

    选择DJ的项目进行启动程序

    http://127.0.0.1:8080/login

    超级管理员账号密码：admin   admin123







"""

from django.conf.urls import url
from django.contrib import admin

from api import pie, san, bar, line, ciyun, run_main, collection, ball, keyword, predict_count, predict_csl
from page import pie_page, san_page, bar_page, line_page, ciyun_page, href_index, ball_page, keyword_page, \
    predict_page_count, predict_page_csl
from . import settings
from django.views.static import serve

urlpatterns = [
    url(r'login/', admin.site.urls),

    url('page/search', href_index.Index.as_view()),

    url('run/main/$', run_main.RequestsMain.as_view()),

    url('api/collection/$', collection.Collection.as_view()),

    url(r'^media/(?P<path>.*)', serve, {"document_root": settings.MEDIA_ROOT}),

    url(r'index/pie', pie_page.Pie.as_view()),

    url(r'api/pie', pie.ApiPie.as_view()),

    url(r'index/san', san_page.San.as_view()),

    url(r'api/san', san.ApiSan.as_view()),

    url(r'index/bar', bar_page.Bar.as_view()),

    url(r'api/bar', bar.ApiBar.as_view()),

    url(r'index/line', line_page.Line.as_view()),

    url(r'api/line', line.ApiLine.as_view()),

    url(r'index/ciyun', ciyun_page.Ciyun.as_view()),

    url(r'api/ciyun', ciyun.CiYunData.as_view()),

    url(r'href/ball', ball_page.Ball.as_view()),

    url(r'api/keyword', ball.ApiKeyWord.as_view()),

    url(r'href/keyword', keyword_page.KeyWord.as_view()),

    url(r'api/tuijian', keyword.ApiKeyWord.as_view()),

    url(r'index/count/predict', predict_page_count.PredictCount.as_view()),

    url(r'api/count/predict', predict_count.PredictCount.as_view()),

    url(r'index/csl/predict', predict_page_csl.PredictCSL.as_view()),

    url(r'api/csl/predict', predict_csl.PredictCSL.as_view())

]
