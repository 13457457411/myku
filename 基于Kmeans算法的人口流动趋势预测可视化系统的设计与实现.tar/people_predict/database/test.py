# import os
# import wordcloud
#
# import os
#
#
# from django.http import JsonResponse
# from rest_framework.views import  APIView
import os

from utils import mysql_pro

mysql_pro.orm_standby()
from database import models


cut_province = models.Value_A.objects.all()



ruo_count = 0
yougan_count= 0
zhongqiang_count = 0
qiang_count = 0
da_count = 0
for i in cut_province:
    zhenji = float(i.poi_id)
    if zhenji < 3:
        ruo_count = ruo_count + 1
    if 3 <=  zhenji <= 4.5:
        yougan_count = yougan_count + 1
    if 4.5 <  zhenji <= 6:
        zhongqiang_count = zhongqiang_count + 1
    if 6 < zhenji <= 8:
        qiang_count = qiang_count + 1
    if  zhenji > 8:
        da_count = da_count + 1
x_list = ["弱震","有感地震","中强震","强震","大地震"]
y_list = [ruo_count,yougan_count,zhongqiang_count,qiang_count,da_count]
print(y_list)

