from django.db import models
from django.utils.html import format_html


# Create your models here.



class Total(models.Model):

    year = models.CharField(max_length=65, verbose_name="年份",null=True,blank=True)
    count = models.FloatField(verbose_name="人口数量",null=True,blank=True)
    start = models.FloatField(verbose_name="出生率", null=True, blank=True)
    end = models.FloatField(verbose_name="死亡率", null=True, blank=True)
    add = models.FloatField(verbose_name="自然增长率", null=True, blank=True)

    def __str__(self):
        return self.year


    class Meta:
        verbose_name = "人口数据"
        verbose_name_plural = verbose_name
        db_table = 'ReqeustsData'





class Yqsm(models.Model):

    year = models.CharField(max_length=65, verbose_name="年份",null=True,blank=True)
    hj = models.FloatField(verbose_name="合计",null=True,blank=True)
    man = models.FloatField(verbose_name="男", null=True, blank=True)
    women = models.FloatField(verbose_name="女", null=True, blank=True)

    def __str__(self):
        return self.year


    class Meta:
        verbose_name = "平均寿命"
        verbose_name_plural = verbose_name
        db_table = 'Yqsm'










