
from django.contrib import admin
from django.http import HttpResponse
from django.utils.html import format_html

from database import models
from openpyxl import Workbook






class Total(admin.ModelAdmin):

    list_display = ('year','count',"start","end","add",)
    list_filter = ['year', ]

    list_per_page = 20
    actions = ["export_as_excel",]


    def export_as_excel(self, request, queryset):
        meta = self.model._meta  # 用于定义文件名, 格式为: app名.模型类名
        field_names = [field.name for field in meta.fields]  # 模型所有字段名
        response = HttpResponse(content_type='application/msexcel')  # 定义响应内容类型
        response['Content-Disposition'] = f'attachment; filename={meta}.xlsx'  # 定义响应数据格式
        wb = Workbook()  # 新建Workbook
        ws = wb.active  # 使用当前活动的Sheet表
        ws.append(field_names)  # 将模型字段名作为标题写入第一行
        for obj in queryset:  # 遍历选择的对象列表
            for field in field_names:
                data = [f'{getattr(obj, field)}' for field in field_names]  # 将模型属性值的文本格式组成列表
            ws.append(data)
        wb.save(response)
        return response
    export_as_excel.short_description = '导出Excel'  # 该动作在admin中的显示文字
    export_as_excel.type = 'warning'
    export_as_excel.icon = 'el-icon-download'

admin.site.register(models.Total, Total)





class Yqsm(admin.ModelAdmin):

    list_display = ('year','hj',"man","women")
    list_filter = ['year', ]

    list_per_page = 20
    actions = ["export_as_excel",]


    def export_as_excel(self, request, queryset):
        meta = self.model._meta  # 用于定义文件名, 格式为: app名.模型类名
        field_names = [field.name for field in meta.fields]  # 模型所有字段名
        response = HttpResponse(content_type='application/msexcel')  # 定义响应内容类型
        response['Content-Disposition'] = f'attachment; filename={meta}.xlsx'  # 定义响应数据格式
        wb = Workbook()  # 新建Workbook
        ws = wb.active  # 使用当前活动的Sheet表
        ws.append(field_names)  # 将模型字段名作为标题写入第一行
        for obj in queryset:  # 遍历选择的对象列表
            for field in field_names:
                data = [f'{getattr(obj, field)}' for field in field_names]  # 将模型属性值的文本格式组成列表
            ws.append(data)
        wb.save(response)
        return response
    export_as_excel.short_description = '导出Excel'  # 该动作在admin中的显示文字
    export_as_excel.type = 'warning'
    export_as_excel.icon = 'el-icon-download'

admin.site.register(models.Yqsm, Yqsm)






admin.site.site_title="人口数据分析预测系统"
admin.site.site_header="人口数据分析预测系统"
admin.site.index_title="人口数据分析预测系统"
