import random
from django.http import JsonResponse
from rest_framework.views import  APIView
from database import models





class ApiLine(APIView):

    def get(self, request):

        data = {}
        name_list = []
        return_list = []
        try:

            find_obj = models.Total.objects.order_by("-id")
            for obj in find_obj:
                name_list.append(obj.year)
                return_list.append(obj.start)

            data['code'] = 200
            data['name_list'] = name_list
            data['return_list'] = return_list
            return JsonResponse(data)

        except Exception as e:
            # print(e)
            data['code'] = 444
            return JsonResponse(data)



