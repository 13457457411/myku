import random
from django.http import JsonResponse
from rest_framework.views import  APIView
from database import models





class ApiPie(APIView):

    def get(self, request):

        data = {}
        try:
            res_list= []

            find_obj = models.Yqsm.objects.order_by("-id")

            for obj in find_obj:
                dict_obj = {}
                dict_obj['value'] = obj.hj
                dict_obj['name'] = obj.year
                res_list.append(dict_obj)

            data['code'] = 200
            data['return_list'] = res_list
            return JsonResponse(data)

        except Exception as e:
            print(e)
            data['code'] = 444
            return JsonResponse(data)



