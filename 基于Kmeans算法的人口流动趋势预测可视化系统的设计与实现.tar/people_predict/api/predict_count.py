import random
from django.http import JsonResponse
from rest_framework.views import  APIView
from database import models
import numpy as np
from datetime import datetime
from sklearn.linear_model import LinearRegression

from utils.mysql_pro import orm_standby


class PredictCount(APIView):

    def get(self, request):

        datas = {}
        try:
            orm_standby()
            data_set = models.Total.objects.all().order_by('year')

            # 训练集
            x_train = []
            y_train = []
            x_count = 0  # 索引
            for data in data_set:
                L = []
                L.append(x_count)
                x_train.append(L)
                y_train.append(int(data.count))  # 放入训练值
                x_count = x_count + 1
            x_train = np.array(x_train)
            y_train = np.array(y_train)
            # 训练数据
            LinObject = LinearRegression()
            LinObject.fit(x_train, y_train)

            # 预测数据数组
            x_preict = []
            y_preict = []
            # 预测
            x_test = []
            for _ in range(5): # 预测值
                L = []
                L.append(x_count + _)
                x_test.append(L)
                x_preict.append(x_count + _)
            p_yred = LinObject.predict(np.array(x_test))
            for p_y in p_yred:
                y_preict.append(int(p_y))

            # 拼接 旧数据与预测数据
            y_raw_list = [int(objs.count) for objs in data_set] # 旧数据

            xList  = [ _ for _ in range(x_test[-1][0])]
            yList =  y_raw_list + y_preict

            datas['x_predict'] = xList
            datas['y_predict'] = yList

            # 旧数据
            datas['y_raw'] = y_raw_list

            datas['code'] = 200
            return JsonResponse(datas)

        except Exception as e:
            print(e)
            datas['code'] = 444
            return JsonResponse(datas)