import random
from django.http import JsonResponse
from rest_framework.views import  APIView
from database import models






class ApiBar(APIView):

    def get(self, request):

        data = {}

        try:
            find_obj = models.Total.objects.order_by("id")


            x = []
            y = []

            for _ in find_obj:
                x.append(_.year)
                y.append(_.count)



            data['code'] = 200
            data['name_list'] = x
            data['return_list'] =  y
            return JsonResponse(data)

        except Exception as e:
            # print(e)
            data['code'] = 444
            return JsonResponse(data)



