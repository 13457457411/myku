import random
import re

import requests
from django.http import JsonResponse
from rest_framework.views import APIView
from database import models
import os
import time
from selenium import webdriver
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
from lxml import etree
import platform
import requests
from fake_useragent import UserAgent
from lxml import etree
import random
import time
import json

def get_ios():
    # 查看系统类型
    platform_ = platform.system()
    if platform_ == "Windows":
        return 1
    else:
        return 2

class RequestsMain(APIView):

    def get(self, request):

        message = {}

        try:
            session = requests.Session()
            page = session.get(
                url="http://quotes.sina.cn/worldmac/?s=compare&a=view&cid=CN&indicate=SP.POP.TOTL&format=json&callback=gotCompareData&time_start=2022&time_len=20")
            page.encoding = "unicode-escape"
            page_text = page.text
            data_str = re.findall('"table":{"data":{"CN":{"SP.POP.TOTL":(.*?)"}', page_text)
            data_res = data_str[0] + '"}'
            res = json.loads(data_res.replace("亿", ""))
            for k,v in res.items():
                if models.Total.objects.filter(year=k).exists() == False:
                    try:
                        models.Total.objects.create(year=k,count=float(v))
                    except:
                        models.Total.objects.create(year=k, count="0")

            message['code'] = 200
            message['message'] = "OK"
            return JsonResponse(message)
        except Exception as e:
            print(e)
            message['code'] = 444
            message['message'] = "爬取异常，请联系管理员Q  995405033 进行处理"
            return JsonResponse(message)
