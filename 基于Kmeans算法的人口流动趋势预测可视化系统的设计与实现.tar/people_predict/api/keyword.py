import random
from django.http import JsonResponse
from rest_framework.views import  APIView
from snownlp import SnowNLP

from database import models




class ApiKeyWord(APIView):

    def get(self, request):

        data = {}
        try:
            res_keyword = []
            color = ["#6600ff", "#3300ff", "#ff0000", "#00ff99", "#cc0000", "#9900ff", "#3300cc", "#3300ff", "#ffff66","#990066", "#ff00ff", ]

            # 推荐
            hot = models.Colect.objects.order_by('?')
            for objj in hot[0:8]:
                # 关键词
                dicts = {}
                dicts['id'] = random.randint(1,20)
                dicts['name'] = objj.co_title
                dicts['num'] = str(random.randint(10, 100)) + "%"
                dicts['color'] = random.choice(color)
                dicts['size'] = [400, 100]
                dicts['borderColor'] = random.choice(color)
                dicts['position'] = [random.randint(10, 200), random.randint(10, 200)]
                res_keyword.append(dicts)

            data['res_keyword'] = res_keyword


            data['code'] = 200
            return JsonResponse(data)

        except Exception as e:
            print(e)
            data['code'] = 444
            return JsonResponse(data)


