import collections
import random
from django.http import JsonResponse
from rest_framework.views import  APIView
from snownlp import SnowNLP
from database import models





class CiYunData(APIView):

    def get(self, request):
        data = {}
        res_list = []
        try:
            res_obj = models.Total.objects.order_by("id")

            for obj in res_obj:
                dict_obj = {}
                dict_obj['value'] = obj.end
                dict_obj['name'] = obj.year
                res_list.append(dict_obj)

            data['res_list'] = res_list
            data['code'] = 200
            return JsonResponse(data)

        except Exception as e:
            print(e)
            data['code'] = 444
            return JsonResponse(data)




    def word_counts_action(self,text, top_number):
        """
            :param text:  统计的文本
            :param top_number:   输出词频前几
            :return: [('非常', 36), ('很', 31), ('手机', 23), ('也', 18)]
        """
        object_list = []
        # 文本预处理
        remove_words = [u'的', u'，', u'和', u'是', u'随着', u'对于', u'对', u'等', u'能', u'都', u'。', u'！', u'你',
                        u'|', u'一', u'不', u'！,', u'了', u'（', u'我', u'看', u'题'
            , u' ', u'、', u'中', u'在', u'】', u',【', u'但', u',', u'通常', u'如果', u'我们', u'需要', u'： ', u'）, ',
                        u'：', u'）,', u'｜', u'？', u'-', u'【', u'）', u',：'
            , u'个', u'语', u'最', u'这', u'讲', u'年', u'+', u'人', u'/', u'如果', u'我们', u'需要', u'： ', u'）, ',
                        u'：', u'）,', u'｜', u'？', u'-', u'【', u'）', u',：',u'1', u'2', u'3', u'4', u'5', u'6', u'7', u'8',
                        u'9', u'。,',
                        ]  # 自定义去除词库
        seg_list_exact = SnowNLP(text).words  # 每一个数组评论分词
        for word in seg_list_exact:  # 循环读出每个分词
            if word not in remove_words:  # 如果不在去除词库中
                object_list.append(word)  # 分词追加到列表
        word_counts = collections.Counter(object_list)  # 对分词做词频统计
        word_top_number = word_counts.most_common(top_number)  # 获取前10最高频的词
        return word_top_number
