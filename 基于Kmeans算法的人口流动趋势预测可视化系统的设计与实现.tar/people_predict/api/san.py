import random
from django.http import JsonResponse
from rest_framework.views import  APIView
from database import models





class ApiSan(APIView):

    def get(self, request):

        data = {}
        try:
            dataBJ = []
            cut_province = models.Value_A.objects.order_by("id")
            # 散点图
            index = 0
            for i in cut_province:
                inner_list = []
                index = index + 1
                inner_list.append(index)
                inner_list.append(i.jingdu)
                inner_list.append(i.poi_id)
                inner_list.append(i.weidu)
                inner_list.append(i.name)
                dataBJ.append(inner_list)

            data['code'] = 200
            data['dataBJ'] = dataBJ
            return JsonResponse(data)

        except Exception as e:
            print(e)
            data['code'] = 444
            return JsonResponse(data)



