# ORM外部配置
import json
import os
import re

import requests


def orm_standby():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "provinceData.settings")  # manage.py文件中有同样的环境配置
    import django
    django.setup()



if __name__ == '__main__':
    orm_standby()
    from database.models import Total,Yqsm  # 导入你的Django应用的模型

    numbers = [0,69.27, 70.47, 0,73.33, 75.25, 77.37, 79.43, 80.88]

    for i in range(1,8):
        Yqsm.objects.filter(pk=i).update(women=numbers[i])





    # session = requests.Session()
    # page = session.get(
    #     url="http://quotes.sina.cn/worldmac/?s=compare&a=view&cid=CN&indicate=SP.POP.TOTL&format=json&callback=gotCompareData&time_start=2022&time_len=20")
    # page.encoding = "unicode-escape"
    # page_text = page.text
    # data_str = re.findall('"table":{"data":{"CN":{"SP.POP.TOTL":(.*?)"}', page_text)
    # data_res = data_str[0] + '"}'
    # res = json.loads(data_res.replace("亿", ""))
    # print('res', res)
    # for k, v in res.items():
    #     if Total.objects.filter(year=k).exists() == False:
    #         try:
    #             Total.objects.create(year=k, count=float(v))
    #         except:
    #             Total.objects.create(year=k, count="0")